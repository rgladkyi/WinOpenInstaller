AltDrag Icon
AltDrag

Easily drag windows when pressing the alt key

 Download v1.1  Portable  Changelog  Documentation
Note: AltDrag will not work properly if you use DPI scaling, read here for a workaround.

Donate

AltDrag is free software and a one-man endeavor. If you find it useful, please make a donation. I greatly appreciate any support!

$
5.00
  Donate with PayPal
Show other donation options: Bitcoin, Square Cash.

News RSS feed

2015-08-23 - AltDrag v1.1 released

Released 1.1. See the changelog here.

There are a few fixes in this new version, but I am mostly being forced to release it because Google Code is shutting down, and this is my last chance to notify the users of v1.0 that there is a new version.

The installer has changed to install into your user�s directory by default. I therefore recommend that you uninstall any previous version and then install from scratch!

I have plans to make the AltDrag source code simpler (by removing features), please see this issue if you have any opinions.

Lastly, I want to thank everyone who have donated. All support is greatly appreciated!

Read older news...

For an RSS feed with only new releases, use the GitHub release feed.

What is AltDrag?

AltDrag gives you the ability to move and resize windows in a new way. After starting AltDrag, you can simply hold down the Alt key and then click and drag any window.

This behavior already exists in Linux and other operating systems, and AltDrag was made with the mission to copy that behavior to the Windows platform, and then to further expand it with new intuitive functionality.

You can use AltDrag in many ways. Here are some examples:

Hold down the Alt key, then drag windows with the left mouse button.
Use the right mouse button to resize windows. It will resize from the corner or edge you grab closest to.
Hold down the Shift key to snap to other windows. You can enable automatic snapping in the options.
If you have automatic snapping enabled, you can hit the Space key to temporarily disable it.
You can scroll inactive windows with the mouse wheel. If you hold down the Shift key while doing this, it will scroll the window horizontally (some programs does not support this).
If you have trouble moving a window, it might be because it's an elevated program (administrator privileges). To move it, you must run AltDrag with administrator privileges too. There is a button in the options to do this.
Windows are not brought to the front by default, hit the Ctrl key to bring a window to the front. You can change this in the options.
Double-click to maximize windows. Double-click with the right mouse button to move it to a corner or side (which one depends on where you double-click).
If you drag a window to an edge or corner of the monitor, it will resize to occupy that space. In Windows-speak, this is called Aero Snap.
You can configure Alt-scrolling to do cool things such as: scroll through open windows, changing the volume, changing transparency. When changing the volume of transparency, you can hold down the Shift key to change it in smaller steps.
You can enable MDI support in the options.
Multi-monitor support! You can hold Ctrl while dragging to trap the window within the current monitor. This is particularly useful if you want to Aero Snap at edges between monitors.
If you move a maximized window from one monitor to another, the window will automatically be maximized on arrival. You can hit the Ctrl key to restore it without needing to release the mouse button.
AltDrag is tested on Windows XP, 7, 8, 8.1 and 10.
AltDrag has more tricks up its sleeve, read through the documentation to learn more.

New languages since last release

Simply save the desired language file in AltDrag's directory. Right-click and Save link as...

Japanese
Read this page to learn how to make your own translation.

Support

See this page for a list of known issues.

Before reporting a bug, look through the list of issues on GitHub.

When reporting a bug, please specify what version of Windows you are using, and be sure to include any error message you might see.

License

AltDrag is free software and licensed under GNU GPL v3. Get the source code on GitHub.

You may redistribute AltDrag on your own website, but please provide a link to this website on the same page. Please do not bundle AltDrag together with toolbars or other annoying adware, or otherwise degrade the experience.

Credits

Made by Stefan Sundin.

You can browse my other projects, or visit my personal website.

Star314

Source: https://stefansundin.github.io/altdrag/